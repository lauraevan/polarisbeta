PolarisFlix Standalone App

Double-click index.html to launch in your browser.
Works offline (data fetched from TMDB on demand).
