PolarisFlix Standalone
======================
Open Polarisflix.html in any modern browser (Chrome, Edge, Safari, Firefox).

Includes: Movies, TV Shows, Anime, Podcasts.
- Movies & TV powered by TMDB + vidsrc.to
- Podcasts powered by Apple Podcasts (iTunes Search API)

No install required. Just double-click the HTML file.
