Polaris OS
==========

Extract this archive and open Polaris.html (or index.html) in your browser
to launch the Polaris desktop.

No installation required.
