SATURDAY OS — Polaris Edition

Double-click 'index.html' (or Polaris.html) to launch.
The OS runs entirely in your browser — no install required.

Includes: Polaris Flix · Polaris Roll · Polaris Games · Music · App Store · Browser · Settings (with Tab Cloakers) · and more.
