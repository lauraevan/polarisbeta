Polaris — Desktop Build

To run:
  1. Extract this folder anywhere.
  2. Double-click "Polaris.html" (or open it in any modern browser).
  3. Wait for the SATURDAY boot screen, then Polaris loads.

For the fullscreen "app" experience, open the file in Chrome / Edge with
the --app flag, for example:
  chrome --app=file:///path/to/Polaris/index.html

A native Electron / Tauri wrapper is on the way.
